/*
 * main.h
 *
 * Created: 2011-10-20 13:56:55
 *  Author: skog
 */ 


#ifndef MAIN_H_
#define MAIN_H_


void main_vbus_action(bool b_high);


#endif /* MAIN_H_ */